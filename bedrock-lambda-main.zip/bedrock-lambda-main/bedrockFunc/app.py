import json
import boto3 
import os
from langchain.llms.bedrock import Bedrock
from langchain import PromptTemplate
from typing import Optional, List, Mapping, Any, Dict
from langchain.retrievers import AmazonKendraRetriever
from langchain.chains import RetrievalQA

#BEDROCK_CLIENT = boto3.client("bedrock", region_name="us-east-1")
KENDRA_CLIENT = boto3.client("kendra", 'us-east-1')
Kendra_indexid = os.getenv("KENDRA_INDEX_ID", None)

model_args = {
                "max_tokens_to_sample":4096,
                "temperature":0.5
            }

llm = Bedrock(model_id="anthropic.claude-v2", verbose = True,model_kwargs = model_args)

def build_chain():
  retriever = AmazonKendraRetriever(index_id=Kendra_indexid)
  prompt_template = """

  Human: This is a friendly conversation between a human and an AI. 
  The AI is talkative and provides specific details from its context but limits it to 240 tokens.
  If the AI does not know the answer to a question, it truthfully says it 
  does not know.

  Assistant: OK, got it, I'll be a talkative truthful AI assistant.

  Human: Here are a few documents in <documents> tags:
  <documents>
  {context}
  </documents>
  Based on the above documents, provide a detailed answer for, {question} Answer "don't know" 
  if not present in the document. 

  Assistant:"""

  PROMPT = PromptTemplate(
      template=prompt_template, input_variables=["context", "question"]
  )
  chain_type_kwargs = {"prompt": PROMPT}
  return RetrievalQA.from_chain_type(
      llm, 
      chain_type="stuff", 
      retriever=retriever, 
      chain_type_kwargs=chain_type_kwargs,
      return_source_documents=True
  )

def run_chain(chain, prompt: str, history=[]):
    result = chain(prompt)
    # To make it compatible with chat samples
    return {
        "answer": result['result'],
        "source_documents": result['source_documents']
    }


def lambda_handler(event, context):
    print(f"boto3-version: {boto3.__version__}")
    print(f"event: {event}")
    event_body = json.loads(event["body"])
    query = event_body["query"]
    print(f"query: {query}")
    
    chain = build_chain()
    result = run_chain(chain, query)
    print(result['answer'])
    
    source_docs = []
    if 'source_documents' in result:
        print('Sources:')
        for d in result['source_documents']:
          print(d.metadata['source'])
          source_docs.append(d.metadata['source'])

    output = {"answer": result['answer'], "source_documents": source_docs}
    
    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "*",
        },
        "body": json.dumps(output)
    }
